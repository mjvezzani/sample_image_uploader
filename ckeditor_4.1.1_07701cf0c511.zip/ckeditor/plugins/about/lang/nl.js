﻿/*
Copyright (c) 2003-2013, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.html or http://ckeditor.com/license
*/
CKEDITOR.plugins.setLang( 'about', 'nl', {
	copy: 'Copyright &copy; $1. Alle rechten voorbehouden.',
	dlgTitle: 'Over CKEditor',
	help: 'Bekijk de $1 voor hulp.',
	moreInfo: 'Voor licentie informatie, bezoek onze website:',
	title: 'Over CKEditor',
	userGuide: 'CKEditor gebruiksaanwijzing'
});
