﻿/*
Copyright (c) 2003-2013, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.html or http://ckeditor.com/license
*/
CKEDITOR.plugins.setLang( 'basicstyles', 'fi', {
	bold: 'Lihavoitu',
	italic: 'Kursivoitu',
	strike: 'Yliviivattu',
	subscript: 'Alaindeksi',
	superscript: 'Yläindeksi',
	underline: 'Alleviivattu'
});
